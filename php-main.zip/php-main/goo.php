<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>
<body>
    <div style="display:flex;
    position: relative;
    margin-left: 28%;
    margin-top: 10%;">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="./img/employe.png" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">se connecter en tant qu'employeur</h5>
    <a style="margin-left: 35%;" href="Employer/login.php" class="btn btn-primary">Login</a>
  </div>
</div>



<div class="card" style="width: 18rem; margin-left: 5%;">
  <img style="    height: 184px;" class="card-img-top" src="./img/entreprise.png" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Se connecter en tant que demandeur d'emploi</h5>
    <a style="margin-left: 35%;" href="demandeur/login.php" class="btn btn-primary">Login</a>
  </div>
</div>
</div>

<div class="mb-3">
    <a style="width: 10%;
    margin-left: 46%;
    margin-top: 3%;" href="./index.php" class="btn btn-secondary">Retour à l'accueil</a>
  </div>

</body>
</html>

